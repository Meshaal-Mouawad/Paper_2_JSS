LEAP Paper 2 - IST R15 LaTeX source

Production-only revision based on R14. Scientific results and evidence are unchanged.
R15 normalizes Listing 1 to native column flow: class-defined in-text spacing (\intextsep),
box alignment based on \fboxsep, and no minipage or manual \vspace/\hspace placement.

Build:
  ./build.sh

Expected output:
  main.pdf
