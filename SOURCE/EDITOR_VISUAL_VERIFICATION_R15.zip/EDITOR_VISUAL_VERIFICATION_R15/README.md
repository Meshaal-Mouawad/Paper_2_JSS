# R15 editor visual verification

These images are direct renders of the submitted R15 PDF.

- `page_04.png`: method guard notation. Visually shows `NULLIF(variable,0)` and `<= 0` semantics.
- `page_05.png`: root-cause discussion. Visually shows `<= 0` semantics and the Gross Margin dossier wording.
- `page_07.png`: Table 5, Table 6 caption, Section 5, and Listing 1.
- `page_7_listing1_crop.png`: focused Listing 1 evidence. The listing is separated from the introductory sentence using native LaTeX/listings flow and class-defined spacing; it shows `if feedstock_input_tons <= 0:`.
- `page_09.png` and `page_10.png`: conclusion and continuous unnumbered references.
- `page_7_pdftotext_layout.txt`: layout-aware text extraction for the same rendered page.

R15 Listing 1 layout uses no `\vspace`, `\hspace`, minipage, manual page break, coordinates, or pixel offsets. Vertical separation comes from the class-defined `\intextsep`; horizontal alignment uses TeX's `\fboxsep` symmetrically.
